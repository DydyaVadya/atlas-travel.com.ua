# Cherry Testi
A testimonials management plugin for WordPress.

## How to use

#### In a post/page
Insert a shortcode `[tm_testimonials]` to the post/page content.

## Changelog

= 1.0.0 =
* Initial release

= 1.0.1 =
* UPD: slider settings for devices
* UPD: parameters list
* UPD: cherry-framework to 1.3.1 version

## Help
Found a bug? Feature requests? [Create an issue - Thanks!](https://github.com/CherryFramework/cherry-testi/issues/new)
